const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const toast = (message) => {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 2800);
};

$('#menuToggle').addEventListener('click', () => {
  $('#navLinks').classList.toggle('open');
});
$$('.nav-links a').forEach(link => link.addEventListener('click', () => $('#navLinks').classList.remove('open')));

document.addEventListener('pointermove', event => {
  const glow = $('#cursorGlow');
  glow.style.left = `${event.clientX}px`;
  glow.style.top = `${event.clientY}px`;
});

function setFaction(mode) {
  const decepticon = mode === 'decepticon';
  document.body.classList.toggle('decepticon', decepticon);
  $('#autobotMode').classList.toggle('active', !decepticon);
  $('#decepticonMode').classList.toggle('active', decepticon);
  $('#transformBtn').textContent = decepticon ? '⟳ VOLTAR AOS AUTOBOTS' : '⟳ TRANSFORMAR!';
  $('#heroRobotImg').src = decepticon
    ? 'assets/megatron.png'
    : 'assets/optimus-prime.png';
  $('#heroRobotImg').alt = decepticon ? 'Megatron, líder dos Decepticons' : 'Optimus Prime, líder dos Autobots';
  $('#heroRobotImg').style.display = 'block';
  $('.robot-fallback').style.display = 'none';
  $('#heroRobotName').textContent = decepticon ? 'MEGATRON' : 'OPTIMUS PRIME';
  $('#heroRobotRole').textContent = decepticon ? 'LÍDER DOS DECEPTICONS' : 'LÍDER DOS AUTOBOTS';
  $('#energyChip').innerHTML = decepticon ? '<span>☠</span> ENERGON: 100% // MODO DOMINAÇÃO' : '<span>⚡</span> ENERGON: 98%';
  $('#statOne').textContent = decepticon ? '13' : '18';
  $('#statLabelOne').textContent = decepticon ? 'CICLOS DE GUERRA' : 'ANOS DE LORE';
  $('#statTwo').textContent = decepticon ? '1' : '2';
  $('#statLabelTwo').textContent = decepticon ? 'OBJETIVO: DOMINAR' : 'MODOS: HUMANO / DEV';
  $('#statThree').textContent = decepticon ? '0%' : '100%';
  $('#statLabelThree').textContent = decepticon ? 'AUTOBOT (INIMIGO)' : 'AUTOBOT (DIZ ELE)';
  $('#factionBg').textContent = decepticon ? 'DECEPTICONS' : 'AUTOBOTS';
  $('#factionIndex').textContent = decepticon ? '03 / PROTOCOLO DE CONQUISTA' : '03 / ALIANÇAS E OBJETIVOS';
  $('#factionHeading').innerHTML = decepticon ? 'DOMÍNIO <span class="blue-word">DECEPTICON</span>' : 'MINHA <span class="blue-word">FACÇÃO</span>';
  $('#factionIntro').textContent = decepticon ? 'Ordem, poder e uma quantidade alarmante de reuniões de alinhamento.' : 'Escolha um lado. O destino de Cybertron está nas suas mãos.';
  $('#factionCharacterImg').src = decepticon
    ? 'assets/megatron.png'
    : 'assets/optimus-prime.png';
  $('#factionCharacterImg').alt = decepticon ? 'Megatron' : 'Optimus Prime';
  $('#characterKicker').textContent = decepticon ? 'AMEAÇA EM DESTAQUE // DECEPTICONS' : 'HERÓI EM DESTAQUE // AUTOBOTS';
  $('#characterName').textContent = decepticon ? 'MEGATRON' : 'OPTIMUS PRIME';
  $('#characterBio').textContent = decepticon
    ? 'Líder dos Decepticons: acredita que o poder resolve tudo. Inclusive bugs — embora normalmente só consiga criar mais três.'
    : 'Líder dos Autobots: acredita que coragem, responsabilidade e trabalho em equipe podem salvar qualquer mundo — inclusive um projeto entregue no prazo.';
  $('#characterQuote').textContent = decepticon ? '“Paz através da tirania.” — plano de gestão questionável.' : '“Até que todos sejam um.”';
  $('#allianceSymbol').textContent = decepticon ? '☠' : '✦';
  $('#allianceKicker').textContent = decepticon ? 'FACÇÃO DOMINANTE' : 'ALIANÇA PRINCIPAL';
  $('#allianceTitle').textContent = decepticon ? 'DECEPTICONS' : 'AUTOBOTS';
  $('#allianceText').textContent = decepticon ? 'Eficiência, ambição e a convicção de que toda reunião poderia ter sido um comunicado ameaçador.' : 'Defendo a liberdade, a amizade e o direito de reiniciar o VS Code quando nada mais resolve.';
  $('#allianceStatus').textContent = decepticon ? '● DOMINAÇÃO EM ANDAMENTO' : '● LEAL ATÉ O FIM';
  $('#secondarySymbol').textContent = decepticon ? '⚡' : '⚽';
  $('#secondaryKicker').textContent = decepticon ? 'DIVISÃO DE PESQUISA' : 'CORAÇÃO TRICOLOR';
  $('#secondaryTitle').textContent = decepticon ? 'CIÊNCIA DUVIDOSA' : 'GRÊMIO 🇪🇪';
  $('#secondaryText').textContent = decepticon ? 'Experimentos para transformar café em energia infinita. O departamento jurídico recomenda não perguntar como.' : 'Azul, preto e branco. A única transformação capaz de mudar meu humor em 90 minutos.';
  $('#secondaryStatus').textContent = decepticon ? '● ÉTICA: EM MANUTENÇÃO' : '● IMORTAL TRICOLOR';
  $('#missionKicker').textContent = decepticon ? 'PLANO DE CONQUISTA' : 'MISSÃO PRINCIPAL';
  $('#missionTitle').textContent = decepticon ? 'ASSUMIR O CONTROLE… DO MERCADO DE TRABALHO.' : 'DOMINAR O UNIVERSO… PROFISSIONALMENTE.';
  $('#missionText').textContent = decepticon ? 'Aprender tecnologia, construir projetos e subir de nível. A dominação mundial pode esperar até depois de entregar o trabalho da faculdade.' : 'Aprender, criar projetos, evoluir no código e provar que um humano também pode ter espírito de Prime.';
  $('#missionStamp').innerHTML = decepticon ? 'GLÓRIA<br>AO MEGATRON' : 'EM<br>ANDAMENTO';
  $('#missionStamp').style.borderColor = decepticon ? '#c05cff' : '';
  $('#missionStamp').style.color = decepticon ? '#d99aff' : '';
  $('#robotCard').classList.remove('transformed');
}
$('#autobotMode').addEventListener('click', () => setFaction('autobot'));
$('#decepticonMode').addEventListener('click', () => setFaction('decepticon'));
$('#transformBtn').addEventListener('click', () => {
  const enteringDecepticons = !document.body.classList.contains('decepticon');
  const card = $('#robotCard');
  card.classList.add('transformed');
  document.body.classList.add('glitch');
  setTimeout(() => {
    setFaction(enteringDecepticons ? 'decepticon' : 'autobot');
    document.body.classList.remove('glitch');
  }, 300);
  toast(enteringDecepticons ? '⚠ DECEPTICONS ASSUMIRAM O CONTROLE! BEM-VINDO AO LADO ROXO.' : 'AUTOBOTS REUNIDOS! A ESPERANÇA VOLTOU A CYBERTRON.');
});

$('#scanBtn').addEventListener('click', () => {
  const result = $('#scanResult');
  const messages = [
    'DIAGNÓSTICO: 99% carisma, 1% bateria social. Recomendação: lanche.',
    'ALERTA: excesso de abas abertas detectado. Nenhuma será fechada.',
    'SISTEMA OK. Gremismo instalado no núcleo e impossível de desinstalar.',
    'BUG CRÍTICO: vontade de ficar rico sem abrir 37 cursos ao mesmo tempo.',
    'ANÁLISE CONCLUÍDA: humano promissor. Continue atualizando a versão.'
  ];
  result.textContent = 'Escaneando sistemas...';
  setTimeout(() => result.textContent = messages[Math.floor(Math.random() * messages.length)], 650);
});

const quizDescriptions = {
  'Optimus Prime': 'RESULTADO: OPTIMUS PRIME. Líder nato. Carrega o grupo, o trabalho e ainda pergunta se todo mundo chegou bem.',
  'Bumblebee': 'RESULTADO: BUMBLEBEE. Energia caótica, coração gigante e trilha sonora até para abrir o navegador.',
  'Ratchet': 'RESULTADO: RATCHET. O médico dos sistemas. Seu “só vou mexer numa coisinha” dura três horas.',
  'Megatron': 'RESULTADO: MEGATRON. Você não corrige o bug. Você intimida o bug até ele pedir demissão.'
};
$$('#quizOptions button').forEach(button => button.addEventListener('click', () => {
  $$('#quizOptions button').forEach(b => b.classList.remove('selected'));
  button.classList.add('selected');
  $('#quizResult').textContent = quizDescriptions[button.dataset.result];
}));

const commandReplies = {
  ajuda: 'COMANDOS: igor | grêmio | transformar | motivação | segredo | ajuda',
  igor: 'IGOR DE OLIVEIRA OURIQUES // CODINOME: IGOR PRIME // CLASSE: HUMANO COM DLC DE DEV.',
  'grêmio': 'IMORTAL TRICOLOR DETECTADO. 🇪🇪 Sistema emocional reforçado para aguentar qualquer rodada.',
  transformar: 'ROLL OUT! 🚛🤖 Use o botão TRANSFORMAR para alternar entre Autobots e Decepticons.',
  decepticons: 'GLÓRIA A MEGATRON! Use o seletor de facção para ativar o tema roxo e o modo Decepticon.',
  autobots: 'AUTOBOTS, ROLL OUT! Use o seletor de facção para restaurar o azul dos heróis.',
  motivação: 'Você não precisa saber tudo hoje. Só precisa continuar aprendendo e não commitar direto na main às 3h da manhã.',
  segredo: 'SEGREDO DESBLOQUEADO: o verdadeiro Energon é o prazo acabando e alguém dizendo “é rapidinho”.'
};
$('#terminalForm').addEventListener('submit', event => {
  event.preventDefault();
  const input = $('#commandInput');
  const command = input.value.trim().toLowerCase();
  if (!command) return;
  const output = $('#terminalOutput');
  const userLine = document.createElement('p');
  userLine.innerHTML = `<span class="term-green">igor@cybertron:~$</span> ${escapeHTML(command)}`;
  output.appendChild(userLine);
  const response = document.createElement('p');
  response.innerHTML = `<span class="term-blue">≫</span> ${escapeHTML(commandReplies[command] || 'COMANDO NÃO RECONHECIDO. O computador está decepcionado, mas acredita em você. Digite “ajuda”.')}`;
  output.appendChild(response);
  input.value = '';
  output.scrollTop = output.scrollHeight;
});
function escapeHTML(value) {
  return value.replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}
$('#clearTerminal').addEventListener('click', () => {
  $('#terminalOutput').innerHTML = '<p><span class="term-blue">CYBERTRON OS</span> — memória limpa. Como se nada tivesse acontecido.</p>';
});

$('#transmissionBtn').addEventListener('click', () => {
  $('#contactNote').textContent = 'TRANSMISSÃO ENVIADA... brincadeira 😎 Este portfólio ainda não está conectado a um e-mail.';
  toast('TRANSMISSÃO SIMULADA COM SUCESSO. NENHUM DECEPTICON AVISTADO.');
});
$('#copyNameBtn').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText('Igor de Oliveira Ouriques');
    $('#contactNote').textContent = 'NOME COPIADO PARA A ÁREA DE TRANSFERÊNCIA. PODE ESPALHAR A LENDA.';
    toast('NOME COPIADO: IGOR DE OLIVEIRA OURIQUES');
  } catch {
    $('#contactNote').textContent = 'Seu navegador bloqueou a cópia automática. Nome: Igor de Oliveira Ouriques';
  }
});

// Animações de entrada sem dependências externas.
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
$$('.section-heading, .panel, .skill-card, .faction-card, .mission-box, .quiz-panel, .terminal, .contact-section').forEach(el => {
  el.classList.add('reveal');
  observer.observe(el);
});

// Contadores do hero.
const countObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    const el = entry.target;
    const target = Number(el.dataset.count);
    let current = 0;
    const step = Math.max(1, Math.ceil(target / 24));
    const timer = setInterval(() => {
      current = Math.min(target, current + step);
      el.textContent = target === 100 ? `${current}%` : current;
      if (current >= target) clearInterval(timer);
    }, 45);
    countObserver.unobserve(el);
  });
}, { threshold: 0.5 });
$$('[data-count]').forEach(el => countObserver.observe(el));
