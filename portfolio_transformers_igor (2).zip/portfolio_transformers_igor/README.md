# IGOR PRIME — Portfólio Transformers

Portfólio de humor com estética sci-fi inspirada no universo de Transformers.

## Como executar
1. Extraia a pasta.
2. Abra `index.html` no navegador ou abra a pasta no VS Code.
3. Recomendado: use a extensão **Live Server** no VS Code e clique em **Go Live**.

## Arquivos
- `index.html`: conteúdo e estrutura.
- `style.css`: visual, responsividade e animações.
- `script.js`: botões, quiz, diagnóstico e terminal interativo.

## Observações
- A imagem principal carrega de um serviço externo; a página possui fallback com emoji se ela não carregar.
- As fontes são carregadas do Google Fonts. Sem internet, o site usa fontes alternativas.
- O botão de transmissão é uma brincadeira e não envia mensagens de verdade.
- O portfólio é um projeto de fã, não oficial e não afiliado à Hasbro/Transformers.
- O botão **Transformar!** alterna entre o tema azul dos Autobots e o tema roxo dos Decepticons, mudando textos, personagem em destaque e informações da facção.
- Redes sociais: Instagram `https://www.instagram.com/igoroouriques/` e GitHub `https://github.com/igoroouriques`.
- As imagens dos personagens usam links do Wikimedia Commons (Special:FilePath), então precisam de internet. Confira a página de origem do arquivo para os créditos/licença da imagem usada.
